lessc ./less/main.less > ./css/main.css
cp -rf ./* ../platforms/ios/www/